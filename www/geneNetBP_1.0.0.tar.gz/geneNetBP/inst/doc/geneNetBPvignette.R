### R code from vignette source 'geneNetBPvignette.Rnw'

###################################################
### code chunk number 1: dataset
###################################################
data(mouse,package="geneNetBP")
head(geno,n=3)
head(pheno,n=3)


###################################################
### code chunk number 2: A
###################################################
if(require("RHugin",quietly=TRUE))
{
library(geneNetBP)
fit.gnbp(geno,pheno)
}


###################################################
### code chunk number 3: B
###################################################
if(require("RHugin",quietly=TRUE))
{
fit.gnbp(geno,pheno,alpha = 0.1)
}


###################################################
### code chunk number 4: B1
###################################################
if(require("RHugin",quietly=TRUE))
{
network<-fit.gnbp(geno,pheno,alpha = 0.1)
##convert the RHugin domain to a graph object
BNgraph<-as.graph.RHuginDomain(network$gp)
##set node font size
attrs<-list()
attrs$node$fontsize<-30
## plot method for graph objects
plot(BNgraph,attrs=attrs) 
}


###################################################
### code chunk number 5: C
###################################################
if(require("RHugin",quietly=TRUE))
{
##Fit network
network<-fit.gnbp(geno,pheno,alpha = 0.1)
##Generate evidence
evidence<-gen.evidence(network,node="Tlr12",std=2,length.out=20)
}


###################################################
### code chunk number 6: F
###################################################
if(require("RHugin",quietly=TRUE))
{
## Fit network
network<-fit.gnbp(geno,pheno,alpha=0.1)
## Absorb evidence
absorb.gnbp(network,node="Tlr12",evidence=matrix(-0.99))
}


###################################################
### code chunk number 7: G
###################################################
if(require("RHugin",quietly=TRUE))
{
## Fit network
network<-fit.gnbp(geno,pheno,alpha=0.1)
##Absorb evidence
absorb.gnbp(network,node="Tlr12",evidence=matrix(2.5,3,3.5,4))
}


###################################################
### code chunk number 8: I
###################################################
if(require("RHugin",quietly=TRUE))
{
## Fit, absorb and plot a genotype-phenotype network
network<-fit.gnbp(geno,pheno,alpha=0.1)
network<-absorb.gnbp(network,node="Tlr12",evidence=matrix(-0.99))
plot(x=network)
}


###################################################
### code chunk number 9: J
###################################################
if(require("RHugin",quietly=TRUE))
{
col.palette<-list(pos_high="darkgreen", pos_low= "palegreen2", 
                    neg_high="wheat1", neg_low = "red",
                    dsep_col="white",qtl_col="grey",node_abs_col="yellow") 
plot(x=network,col.palette=col.palette)
}


###################################################
### code chunk number 10: K
###################################################
if(require("RHugin",quietly=TRUE))
{
##Fit network
network<-fit.gnbp(geno,pheno,alpha = 0.1)
##Generate evidence
evidence<-gen.evidence(network,node="Tlr12",std=2,length.out=20)
network<-absorb.gnbp(network,node="Tlr12",evidence=evidence)
plot(x=network,y="belief",ncol=20)
}


###################################################
### code chunk number 11: L
###################################################
## Load the toy dataset
library(geneNetBP)
data(toy)
## Create a list of edges ("from (parent)", "to (child)")
edgelist=list()
edgelist[[1]]<-cbind("Q1","X1")
edgelist[[2]]<-cbind("Q2","X1")
edgelist[[3]]<-cbind("Q2","X2")
edgelist[[4]]<-cbind("Q2","X4")
edgelist[[5]]<-cbind("X1","X2")
edgelist[[6]]<-cbind("Q3","X2")
edgelist[[7]]<-cbind("Q3","X3")
edgelist[[8]]<-cbind("X2","X5")
edgelist[[9]]<-cbind("X2","X6")
edgelist[[10]]<-cbind("X4","X6")


###################################################
### code chunk number 12: M
###################################################
if(require("RHugin",quietly=TRUE))
{
##Fit network
network<-fit.gnbp(toygeno,toypheno,learn=FALSE,edgelist=edgelist)
##Generate evidence
evidence<-gen.evidence(network,node="X2",std=2,length.out=20)
network<-absorb.gnbp(network,node="X2",evidence=evidence)
plot(x=network,y="JSI",ncol=17)
}


